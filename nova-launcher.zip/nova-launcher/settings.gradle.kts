rootProject.name = "nova-launcher"
